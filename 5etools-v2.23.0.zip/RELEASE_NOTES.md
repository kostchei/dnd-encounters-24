v2.23.0, "Salvia Officinalis" Edition

- Added _Sage Advice Compendium (2025)_ (thanks @ Lyra)
- Added "'14 Sources" quick-block/unblock buttons to Blocklist
- Fixed position of context menus when opened near bottom of window
- Fixed crash when saving DM Screen state for non-primary panel tabs
- (Fixed typos/added tags)
